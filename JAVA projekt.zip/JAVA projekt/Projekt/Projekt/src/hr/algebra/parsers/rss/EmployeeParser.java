/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.parsers.rss;

import hr.algebra.factory.ParserFactory;
import hr.algebra.factory.UrlConnectionFactory;
import hr.algebra.models.Employee;
import hr.algebra.utils.FileUtils;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

/**
 *
 * @author dbasi
 */
public class EmployeeParser {

    private static final String RSS_URL = "https://www.blitz-cinestar-bh.ba/rss.aspx?id=2682";
    private static final String DEF_EMP = "https://www.iconsdb.com/icons/preview/gray/user-xxl.png";
    private static final String DIR = "assets";

    public static List<Employee> parse() throws IOException, XMLStreamException {
        List<Employee> employees = new ArrayList<>();

        HttpURLConnection con = UrlConnectionFactory.getHttpUrlConnection(RSS_URL);

        try (InputStream is = con.getInputStream()) {
            XMLEventReader reader = ParserFactory.createStaxParser(is);

            Optional<TagType> tagType = Optional.empty();
            Employee employee = null;
            StartElement startElement = null;

            while (reader.hasNext()) {
                XMLEvent event = reader.nextEvent();

                switch (event.getEventType()) {
                    case XMLStreamConstants.START_ELEMENT:
                        startElement = event.asStartElement();
                        String qName = startElement.getName().getLocalPart(); // imena tagova u qualified nameu
                        tagType = TagType.from(qName);

                        if (tagType.isPresent() && tagType.get().equals(TagType.REDATELJ)) {
                            employee = new Employee();
                            employees.add(employee);
                        }
                        break;
                    case XMLStreamConstants.CHARACTERS:
                        if (tagType.isPresent() && employee != null) {
                            Characters characters = event.asCharacters();
                            String data = characters.getData().trim();

                            switch (tagType.get()) {
                                case REDATELJ:
                                    if (!data.isEmpty()) {
                                        String[] fullNames = data.split(", ");
                                        for (int i = 0; i < fullNames.length; i++) {
                                            String[] nameSurname = fullNames[i].split(" ");

                                            // flawed logic, this is probably not the way to do it
                                            if (employee.getFirstName() != null) { // ako je trenutnom employee-u u scopeu vec setano ime znaci da moram napravit novog
                                                employee = new Employee();
                                                employees.add(employee);

                                                employee.setFirstName(nameSurname[0]);
                                                if (nameSurname.length == 1) { // potrebno jer sam uvidio da neki employee nemaju ime prezime nego samo ime definirano
                                                    employee.setLastName("N/A");
                                                } else {
                                                    employee.setLastName(nameSurname[1]);
                                                }
                                                employee.setMovieRoleId(2);
                                                handleNoImage(employee, DEF_EMP);

                                            } else { // ako nije znaci da je prvi employee u scopeu i da mogu samo setat sto trebam
                                                employee.setFirstName(nameSurname[0]);
                                                if (nameSurname.length == 1) {
                                                    employee.setLastName("N/A");
                                                } else {
                                                    employee.setLastName(nameSurname[1]);
                                                }
                                                employee.setMovieRoleId(2); // director role je pod id 2
                                                handleNoImage(employee, DEF_EMP); // per default svaki employee nema sliku, ali jer je not null u bazi, moram postavit nesto
                                            }

                                        }
                                    }
                                    break;
                                case GLUMCI:
                                    if (!data.isEmpty()) {
                                        String[] fullNames = data.split(", ");
                                        for (int i = 0; i < fullNames.length; i++) {
                                            String[] nameSurname = fullNames[i].split(" ");

                                            // flawed logic, this is probably not the way to do it
                                            if (!employee.getFirstName().isEmpty()) {
                                                employee = new Employee();
                                                employees.add(employee);

                                                employee.setFirstName(nameSurname[0]);
                                                if (nameSurname.length == 1) {
                                                    employee.setLastName("N/A");
                                                } else {
                                                    employee.setLastName(nameSurname[1]);
                                                }
                                                employee.setMovieRoleId(1);
                                                handleNoImage(employee, DEF_EMP);

                                            } else { // ako nije znaci da je prvi employee u scopeu i da mogu samo setat sto trebam
                                                employee.setFirstName(nameSurname[0]);
                                                if (nameSurname.length == 1) {
                                                    employee.setLastName("N/A");
                                                } else {
                                                    employee.setLastName(nameSurname[1]);
                                                }
                                                employee.setMovieRoleId(1);
                                                handleNoImage(employee, DEF_EMP);
                                            }

                                        }
                                    }
                                    break;
                            }
                        }
                        break;
                }

            }

        }

        return employees;
    }

    private static void handleNoImage(Employee employee, String url) throws IOException {

        String ext = url.substring(url.lastIndexOf("."));

        String name = UUID.randomUUID() + ext;
        String localPath = DIR + File.separator + name;

        FileUtils.copyFromUrl(url, localPath);

        employee.setPicturePath(localPath);
    }

    private enum TagType {
        REDATELJ("redatelj"),
        GLUMCI("glumci");

        private final String name;

        private TagType(String name) {
            this.name = name;
        }

        private static Optional<TagType> from(String name) {

            for (TagType value : values()) {
                if (value.name.equals(name)) {
                    return Optional.of(value);
                }
            }

            return Optional.empty();
        }
    }
}
