/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.dal;

import hr.algebra.models.Employee;
import hr.algebra.models.Movie;
import hr.algebra.models.User;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author dnlbe
 */
public interface Repository {
    
    int createAdmin() throws Exception;
    int createUser(User user) throws Exception;
    Optional<User> selectUser(int id) throws Exception;
    void deleteUser(int id) throws Exception;
    List<User> selectUsers() throws Exception;
    
    int createEmployee(Employee employee) throws Exception;
    void createEmployees(List<Employee> employees) throws Exception;
    Optional<Employee> selectEmployee(int id) throws Exception;
    void updateEmployee(Employee data, int id) throws Exception;
    void deleteEmployee(int id) throws Exception;
    List<Employee> selectEmployees() throws Exception;
    
    int createMovie(Movie movie) throws Exception;
    void createMovies(List<Movie> movies) throws Exception;
    Optional<Movie> selectMovie(int id) throws Exception;
    void updateMovie(Movie data, int id) throws Exception;
    void deleteMovie(int id) throws Exception;
    List<Movie> selectMovies() throws Exception;
    
    void addActorToMovie(int idEmployee, int idMovie) throws Exception;
    void deleteActorFromMovie(int idEmployee, int idMovie) throws Exception;
    void deleteActorFromAllMovies(int idEmployee) throws Exception;
    List<Movie> selectAllMoviesOfActor(int idEmployee) throws Exception;
    List<Employee> selectAllActorsOnMovie(int idMovie) throws Exception;
    void deleteMovieWithActor(int idMovie, int idEmployee) throws Exception;
    
    void addDirectorToMovie(int idEmployee, int idMovie) throws Exception;
    void deleteDirectorFromMovie(int idEmployee, int idMovie) throws Exception;
    void deleteDirectorFromAllMovies(int idEmployee) throws Exception;
    List<Movie> selectAllMoviesOfDirector(int idEmployee) throws Exception;
    List<Employee> selectAllDirectorsOnMovie(int idMovie) throws Exception;
    void deleteMovieWithDirector(int idMovie, int idEmployee) throws Exception;
    
    void wipeAllData() throws Exception;
}
