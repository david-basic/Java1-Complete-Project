/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.dal.sql;

import hr.algebra.dal.Repository;
import hr.algebra.models.Employee;
import hr.algebra.models.Movie;
import hr.algebra.models.User;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.sql.DataSource;

public class SqlRepository implements Repository {

    private static final String ID_USER = "IDUser";
    private static final String NICKNAME = "Nickname";
    private static final String USERNAME = "Username";
    private static final String PASSWORD = "UserPassword";
    private static final String ROLE_ID = "RoleID";

    private static final String ID_EMPLOYEE = "IDEmployee";
    private static final String EMPLOYEE_FIRST_NAME = "FirstName";
    private static final String EMPLOYEE_LAST_NAME = "LastName";
    private static final String EMPLOYEE_MOVIE_ROLE_ID = "MovieRoleID";
    private static final String EMPLOYEE_PICTURE_PATH = "PicturePath";

    private static final String ID_MOVIE = "IDMovie";
    private static final String TITLE = "Title";
    private static final String GENRE = "Genre";
    private static final String YEAR_PUBLISHED = "YearPublished";
    private static final String DURATION = "Duration";
    private static final String MOVIE_DESCRIPTION = "MovieDescription";
    private static final String LINK = "Link";
    private static final String MOVIE_PICTURE_PATH = "PicturePath";

    private static final String CREATE_ADMIN = "{ CALL createAdmin (?) }";
    private static final String CREATE_USER = "{ CALL createUser (?,?,?,?,?) }";
    private static final String SELECT_USER = "{ CALL selectUser (?) }";
    private static final String DELETE_USER = "{ CALL deleteUser (?) }";
    private static final String SELECT_USERS = "{ CALL selectUsers }";

    private static final String CREATE_EMPLOYEE = "{ CALL createEmployee (?,?,?,?,?) }";
    private static final String SELECT_EMPLOYEE = "{ CALL selectEmployee (?) }";
    private static final String UPDATE_EMPLOYEE = "{ CALL updateEmployee (?,?,?,?,?) }";
    private static final String DELETE_EMPLOYEE = "{ CALL deleteEmployee (?) }";
    private static final String SELECT_EMPLOYEES = "{ CALL selectEmployees }";

    private static final String CREATE_MOVIE = "{ CALL createMovie (?,?,?,?,?,?,?,?) }";
    private static final String SELECT_MOVIE = "{ CALL selectMovie (?) }";
    private static final String UPDATE_MOVIE = "{ CALL updateMovie (?,?,?,?,?,?,?,?) }";
    private static final String DELETE_MOVIE = "{ CALL deleteMovie (?) }";
    private static final String SELECT_MOVIES = "{ CALL selectMovies }";

    private static final String ADD_ACTOR_TO_MOVIE = "{ CALL addActorToMovie (?,?) }";
    private static final String DELETE_ACTOR_FROM_MOVIE = "{ CALL deleteActorFromMovie (?,?) }";
    private static final String DELETE_ACTOR_FROM_ALL_MOVIES = "{ CALL deleteActorFromAllMovies (?) }";
    private static final String SELECT_ALL_MOVIES_OF_ACTOR = "{ CALL selectAllMoviesOfActor (?) }";
    private static final String SELECT_ALL_ACTORS_ON_MOVIE = "{ CALL selectAllActorsOnMovie (?) }";
    private static final String DELETE_MOVIE_WITH_ACTOR = "{ CALL deleteMovieWithActor (?,?) }";

    private static final String ADD_DIRECTOR_TO_MOVIE = "{ CALL addDirectorToMovie (?,?) }";
    private static final String DELETE_DIRECTOR_FROM_MOVIE = "{ CALL deleteDirectorFromMovie (?,?) }";
    private static final String DELETE_DIRECTOR_FROM_ALL_MOVIES = "{ CALL deleteDirectorFromAllMovies (?) }";
    private static final String SELECT_ALL_MOVIES_OF_DIRECTOR = "{ CALL selectAllMoviesOfDirector (?) }";
    private static final String SELECT_ALL_DIRECTORS_ON_MOVIE = "{ CALL selectAllDirectorsOnMovie (?) }";
    private static final String DELETE_MOVIE_WITH_DIRECTOR = "{ CALL deleteMovieWithDirector (?,?) }";

    private static final String WIPE_ALL_DATA = "{ CALL wipeAllData }";

    @Override
    public int createAdmin() throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(CREATE_ADMIN)) {
            stmt.registerOutParameter("@" + ID_USER, Types.INTEGER);

            stmt.executeUpdate();

            return stmt.getInt("@" + ID_USER);
        }
    }

    @Override
    public int createUser(User user) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(CREATE_USER)) {
            stmt.setString("@" + NICKNAME, user.getNickname());
            stmt.setString("@" + USERNAME, user.getUsername());
            stmt.setString("@" + PASSWORD, user.getPassword());
            stmt.setInt("@" + ROLE_ID, user.getRoleId());
            stmt.registerOutParameter("@" + ID_USER, Types.INTEGER);

            stmt.executeUpdate();

            return stmt.getInt("@" + ID_USER);
        }
    }

    @Override
    public Optional<User> selectUser(int id) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(SELECT_USER)) {
            stmt.setInt("@" + ID_USER, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new User(
                            rs.getInt(ID_USER),
                            rs.getString(NICKNAME),
                            rs.getString(USERNAME),
                            rs.getString(PASSWORD),
                            rs.getInt(ROLE_ID)
                    ));
                }
            }
        }

        return Optional.empty();
    }

    @Override
    public void deleteUser(int id) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(DELETE_USER)) {

            stmt.setInt("@" + ID_USER, id);

            stmt.executeUpdate();
        }
    }

    @Override
    public List<User> selectUsers() throws Exception {
        List<User> users = new ArrayList<>();
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(SELECT_USERS);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                users.add(new User(
                        rs.getInt(ID_USER),
                        rs.getString(NICKNAME),
                        rs.getString(USERNAME),
                        rs.getString(PASSWORD),
                        rs.getInt(ROLE_ID)
                ));
            }
        }
        return users;
    }

    @Override
    public int createEmployee(Employee employee) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(CREATE_EMPLOYEE)) {
            stmt.setString("@" + EMPLOYEE_FIRST_NAME, employee.getFirstName());
            stmt.setString("@" + EMPLOYEE_LAST_NAME, employee.getLastName());
            stmt.setInt("@" + EMPLOYEE_MOVIE_ROLE_ID, employee.getMovieRoleId());
            stmt.setString("@" + EMPLOYEE_PICTURE_PATH, employee.getPicturePath());
            stmt.registerOutParameter("@" + ID_EMPLOYEE, Types.INTEGER);

            stmt.executeUpdate();

            return stmt.getInt("@" + ID_EMPLOYEE);
        }
    }

    @Override
    public void createEmployees(List<Employee> employees) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(CREATE_EMPLOYEE)) {

            for (Employee employee : employees) {
                stmt.setString("@" + EMPLOYEE_FIRST_NAME, employee.getFirstName());
                stmt.setString("@" + EMPLOYEE_LAST_NAME, employee.getLastName());
                stmt.setInt("@" + EMPLOYEE_MOVIE_ROLE_ID, employee.getMovieRoleId());
                stmt.setString("@" + EMPLOYEE_PICTURE_PATH, employee.getPicturePath());
                stmt.registerOutParameter("@" + ID_EMPLOYEE, Types.INTEGER);

                stmt.executeUpdate();
            }
        }
    }

    @Override
    public Optional<Employee> selectEmployee(int id) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(SELECT_EMPLOYEE)) {
            stmt.setInt("@" + ID_EMPLOYEE, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new Employee(
                            rs.getInt(ID_EMPLOYEE),
                            rs.getString(EMPLOYEE_FIRST_NAME),
                            rs.getString(EMPLOYEE_LAST_NAME),
                            rs.getInt(EMPLOYEE_MOVIE_ROLE_ID),
                            rs.getString(EMPLOYEE_PICTURE_PATH)
                    ));
                }
            }
        }

        return Optional.empty();
    }

    @Override
    public void updateEmployee(Employee data, int id) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(UPDATE_EMPLOYEE)) {
            stmt.setString("@" + EMPLOYEE_FIRST_NAME, data.getFirstName());
            stmt.setString("@" + EMPLOYEE_LAST_NAME, data.getLastName());
            stmt.setInt("@" + EMPLOYEE_MOVIE_ROLE_ID, data.getMovieRoleId());
            stmt.setString("@" + EMPLOYEE_PICTURE_PATH, data.getPicturePath());
            stmt.setInt("@" + ID_EMPLOYEE, id);

            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteEmployee(int id) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(DELETE_EMPLOYEE)) {

            stmt.setInt("@" + ID_EMPLOYEE, id);

            stmt.executeUpdate();
        }
    }

    @Override
    public List<Employee> selectEmployees() throws Exception {
        List<Employee> employees = new ArrayList<>();
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(SELECT_EMPLOYEES);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                employees.add(new Employee(
                        rs.getInt(ID_EMPLOYEE),
                        rs.getString(EMPLOYEE_FIRST_NAME),
                        rs.getString(EMPLOYEE_LAST_NAME),
                        rs.getInt(EMPLOYEE_MOVIE_ROLE_ID),
                        rs.getString(EMPLOYEE_PICTURE_PATH)
                ));
            }
        }
        return employees;
    }

    @Override
    public int createMovie(Movie movie) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(CREATE_MOVIE)) {
            stmt.setString("@" + TITLE, movie.getTitle());
            stmt.setString("@" + GENRE, movie.getGenre());
            stmt.setInt("@" + YEAR_PUBLISHED, movie.getYearPublished());
            stmt.setInt("@" + DURATION, movie.getDuration());
            stmt.setString("@" + MOVIE_DESCRIPTION, movie.getMovieDescription());
            stmt.setString("@" + LINK, movie.getLink());
            stmt.setString("@" + MOVIE_PICTURE_PATH, movie.getPicturePath());
            stmt.registerOutParameter("@" + ID_MOVIE, Types.INTEGER);

            stmt.executeUpdate();

            return stmt.getInt("@" + ID_MOVIE);
        }
    }

    @Override
    public void createMovies(List<Movie> movies) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(CREATE_MOVIE)) {

            for (Movie movie : movies) {

                stmt.setString("@" + TITLE, movie.getTitle());
                stmt.setString("@" + GENRE, movie.getGenre());
                stmt.setInt("@" + YEAR_PUBLISHED, movie.getYearPublished());
                stmt.setInt("@" + DURATION, movie.getDuration());
                stmt.setString("@" + MOVIE_DESCRIPTION, movie.getMovieDescription());
                stmt.setString("@" + LINK, movie.getLink());
                stmt.setString("@" + MOVIE_PICTURE_PATH, movie.getPicturePath());
                stmt.registerOutParameter("@" + ID_MOVIE, Types.INTEGER);

                stmt.executeUpdate();
            }
        }
    }

    @Override
    public Optional<Movie> selectMovie(int id) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(SELECT_MOVIE)) {
            stmt.setInt("@" + ID_MOVIE, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new Movie(
                            rs.getInt(ID_MOVIE),
                            rs.getString(TITLE),
                            rs.getString(GENRE),
                            rs.getInt(YEAR_PUBLISHED),
                            rs.getInt(DURATION),
                            rs.getString(MOVIE_DESCRIPTION),
                            rs.getString(LINK),
                            rs.getString(MOVIE_PICTURE_PATH)
                    ));
                }
            }
        }

        return Optional.empty();
    }

    @Override
    public void updateMovie(Movie data, int id) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(UPDATE_MOVIE)) {
            stmt.setString("@" + TITLE, data.getTitle());
            stmt.setString("@" + GENRE, data.getGenre());
            stmt.setInt("@" + YEAR_PUBLISHED, data.getYearPublished());
            stmt.setInt("@" + DURATION, data.getDuration());
            stmt.setString("@" + MOVIE_DESCRIPTION, data.getMovieDescription());
            stmt.setString("@" + LINK, data.getLink());
            stmt.setString("@" + MOVIE_PICTURE_PATH, data.getPicturePath());
            stmt.setInt("@" + ID_MOVIE, data.getId());

            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteMovie(int id) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(DELETE_MOVIE)) {

            stmt.setInt("@" + ID_MOVIE, id);

            stmt.executeUpdate();
        }
    }

    @Override
    public List<Movie> selectMovies() throws Exception {
        List<Movie> movies = new ArrayList<>();
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(SELECT_MOVIES);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                movies.add(new Movie(
                        rs.getInt(ID_MOVIE),
                        rs.getString(TITLE),
                        rs.getString(GENRE),
                        rs.getInt(YEAR_PUBLISHED),
                        rs.getInt(DURATION),
                        rs.getString(MOVIE_DESCRIPTION),
                        rs.getString(LINK),
                        rs.getString(MOVIE_PICTURE_PATH)
                ));
            }
        }
        return movies;
    }

    @Override
    public void addActorToMovie(int idEmployee, int idMovie) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(ADD_ACTOR_TO_MOVIE)) {
            stmt.setInt("@" + ID_EMPLOYEE, idEmployee);
            stmt.setInt("@" + ID_MOVIE, idMovie);

            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteActorFromMovie(int idEmployee, int idMovie) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(DELETE_ACTOR_FROM_MOVIE)) {

            stmt.setInt("@" + ID_EMPLOYEE, idEmployee);
            stmt.setInt("@" + ID_MOVIE, idMovie);

            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteActorFromAllMovies(int idEmployee) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(DELETE_ACTOR_FROM_ALL_MOVIES)) {

            stmt.setInt("@" + ID_EMPLOYEE, idEmployee);

            stmt.executeUpdate();
        }
    }

    @Override
    public List<Movie> selectAllMoviesOfActor(int idEmployee) throws Exception {
        List<Movie> movies = new ArrayList<>();
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(SELECT_ALL_MOVIES_OF_ACTOR);
                ResultSet rs = stmt.executeQuery()) {

            stmt.setInt("@" + ID_EMPLOYEE, idEmployee);
            while (rs.next()) {
                movies.add(new Movie(
                        rs.getInt(ID_MOVIE),
                        rs.getString(TITLE),
                        rs.getString(GENRE),
                        rs.getInt(YEAR_PUBLISHED),
                        rs.getInt(DURATION),
                        rs.getString(MOVIE_DESCRIPTION),
                        rs.getString(LINK),
                        rs.getString(MOVIE_PICTURE_PATH)
                ));
            }
        }
        return movies;
    }

    @Override
    public List<Employee> selectAllActorsOnMovie(int idMovie) throws Exception {
        List<Employee> employees = new ArrayList<>();
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(SELECT_ALL_ACTORS_ON_MOVIE);
                ResultSet rs = stmt.executeQuery()) {

            stmt.setInt("@" + ID_MOVIE, idMovie);
            while (rs.next()) {
                employees.add(new Employee(
                        rs.getInt(ID_EMPLOYEE),
                        rs.getString(EMPLOYEE_FIRST_NAME),
                        rs.getString(EMPLOYEE_LAST_NAME),
                        rs.getInt(EMPLOYEE_MOVIE_ROLE_ID),
                        rs.getString(EMPLOYEE_PICTURE_PATH)
                ));
            }
        }
        return employees;
    }

    @Override
    public void deleteMovieWithActor(int idMovie, int idEmployee) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(DELETE_MOVIE_WITH_ACTOR)) {

            stmt.setInt("@" + ID_MOVIE, idMovie);
            stmt.setInt("@" + ID_EMPLOYEE, idEmployee);

            stmt.executeUpdate();
        }
    }

    @Override
    public void addDirectorToMovie(int idEmployee, int idMovie) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(ADD_DIRECTOR_TO_MOVIE)) {
            stmt.setInt("@" + ID_EMPLOYEE, idEmployee);
            stmt.setInt("@" + ID_MOVIE, idMovie);

            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteDirectorFromMovie(int idEmployee, int idMovie) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(DELETE_DIRECTOR_FROM_MOVIE)) {

            stmt.setInt("@" + ID_EMPLOYEE, idEmployee);
            stmt.setInt("@" + ID_MOVIE, idMovie);

            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteDirectorFromAllMovies(int idEmployee) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(DELETE_DIRECTOR_FROM_ALL_MOVIES)) {

            stmt.setInt("@" + ID_EMPLOYEE, idEmployee);

            stmt.executeUpdate();
        }
    }

    @Override
    public List<Movie> selectAllMoviesOfDirector(int idEmployee) throws Exception {
        List<Movie> movies = new ArrayList<>();
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(SELECT_ALL_MOVIES_OF_DIRECTOR);
                ResultSet rs = stmt.executeQuery()) {

            stmt.setInt("@" + ID_EMPLOYEE, idEmployee);
            while (rs.next()) {
                movies.add(new Movie(
                        rs.getInt(ID_MOVIE),
                        rs.getString(TITLE),
                        rs.getString(GENRE),
                        rs.getInt(YEAR_PUBLISHED),
                        rs.getInt(DURATION),
                        rs.getString(MOVIE_DESCRIPTION),
                        rs.getString(LINK),
                        rs.getString(MOVIE_PICTURE_PATH)
                ));
            }
        }
        return movies;
    }

    @Override
    public List<Employee> selectAllDirectorsOnMovie(int idMovie) throws Exception {
        List<Employee> employees = new ArrayList<>();
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(SELECT_ALL_DIRECTORS_ON_MOVIE);
                ResultSet rs = stmt.executeQuery()) {

            stmt.setInt("@" + ID_MOVIE, idMovie);
            while (rs.next()) {
                employees.add(new Employee(
                        rs.getInt(ID_EMPLOYEE),
                        rs.getString(EMPLOYEE_FIRST_NAME),
                        rs.getString(EMPLOYEE_LAST_NAME),
                        rs.getInt(EMPLOYEE_MOVIE_ROLE_ID),
                        rs.getString(EMPLOYEE_PICTURE_PATH)
                ));
            }
        }
        return employees;
    }

    @Override
    public void deleteMovieWithDirector(int idMovie, int idEmployee) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(DELETE_MOVIE_WITH_DIRECTOR)) {

            stmt.setInt("@" + ID_MOVIE, idMovie);
            stmt.setInt("@" + ID_EMPLOYEE, idEmployee);

            stmt.executeUpdate();
        }
    }

    @Override
    public void wipeAllData() throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(WIPE_ALL_DATA)) {

            stmt.executeUpdate();
        }
    }
}
