/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.models;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;

/**
 *
 * @author dbasi
 */
public class EmployeeTransferable implements Transferable {

    public static final DataFlavor EMPLOYEE_FLAVOR = new DataFlavor(Employee.class, "Employee");
    private static final DataFlavor[] SUPPORTED_TRANSFERABLE = {EMPLOYEE_FLAVOR};

    private final Employee employee;

    public EmployeeTransferable(Employee employee) {
        this.employee = employee;
    }

    @Override
    public DataFlavor[] getTransferDataFlavors() {
        return SUPPORTED_TRANSFERABLE;
    }

    @Override
    public boolean isDataFlavorSupported(DataFlavor flavor) {
        return EMPLOYEE_FLAVOR.equals(flavor);
    }

    @Override
    public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException {
        if (isDataFlavorSupported(flavor)) {
            return employee;
        }
        throw new UnsupportedFlavorException(flavor);
    }

}
