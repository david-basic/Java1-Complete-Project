/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.models;

/**
 *
 * @author dbasi
 */
public class MovieDirection {
    private int IDMovieDirection;
    private int employeeID;
    private int movieID;

    public MovieDirection() {
    }

    public MovieDirection(int IDMovieDirection, int employeeID, int movieID) {
        this.IDMovieDirection = IDMovieDirection;
        this.employeeID = employeeID;
        this.movieID = movieID;
    }

    public MovieDirection(int employeeID, int movieID) {
        this.employeeID = employeeID;
        this.movieID = movieID;
    }

    public int getIDMovieDirection() {
        return IDMovieDirection;
    }

    public void setIDMovieDirection(int IDMovieDirection) {
        this.IDMovieDirection = IDMovieDirection;
    }

    public int getDirectorID() {
        return employeeID;
    }

    public void setDirectorID(int employeeID) {
        this.employeeID = employeeID;
    }

    public int getMovieID() {
        return movieID;
    }

    public void setMovieID(int movieID) {
        this.movieID = movieID;
    }
}
