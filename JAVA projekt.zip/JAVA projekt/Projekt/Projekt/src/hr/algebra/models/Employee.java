/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.models;

import java.util.Comparator;
import java.util.Objects;

/**
 *
 * @author dbasi
 */
public class Employee implements Comparable<Employee> {

    private int id;
    private String firstName;
    private String lastName;
    private int movieRoleId;
    private String picturePath;

    public Employee() {
    }

    public Employee(int id, String firstName, String lastName, int movieRoleId, String picturePath) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.movieRoleId = movieRoleId;
        this.picturePath = picturePath;
    }

    public Employee(String firstName, String lastName, int movieRoleId, String picturePath) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.movieRoleId = movieRoleId;
        this.picturePath = picturePath;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getMovieRoleId() {
        return movieRoleId;
    }

    public void setMovieRoleId(int movieRoleId) {
        this.movieRoleId = movieRoleId;
    }

    public String getPicturePath() {
        return picturePath;
    }

    public void setPicturePath(String picturePath) {
        this.picturePath = picturePath;
    }

    @Override
    public String toString() {
        String role = movieRoleId == 1 ? "Actor" : "Director";
        return firstName + " " + lastName + " (" + role + ")";
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 79 * hash + Objects.hashCode(this.firstName);
        hash = 79 * hash + Objects.hashCode(this.lastName);
        hash = 79 * hash + this.movieRoleId;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Employee other = (Employee) obj;
        if (this.movieRoleId != other.movieRoleId) {
            return false;
        }
        if (!Objects.equals(this.firstName, other.firstName)) {
            return false;
        }
        if (!Objects.equals(this.lastName, other.lastName)) {
            return false;
        }
        return true;
    }

    @Override
    public int compareTo(Employee o) {
        return Comparator.comparing(Employee::getFirstName)
                .thenComparing(Employee::getLastName)
                .thenComparingInt(Employee::getMovieRoleId)
                .compare(this, o);
    }

}
