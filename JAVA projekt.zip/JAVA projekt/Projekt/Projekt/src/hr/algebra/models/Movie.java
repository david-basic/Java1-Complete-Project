/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.models;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author dbasi
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"title", "genre", "yearPublished", "duration", "movieDescription", "link", "picturePath"})
public class Movie implements Comparable<Movie> {
    
    private int id;
    private String title;
    private String genre;
    private int yearPublished;
    private int duration;
    private String movieDescription;
    private String link;
    private String picturePath;

    public Movie() {
    }

    public Movie(int id, String title, String genre, int yearPublished, int duration, String movieDescription, String link, String picturePath) {
        this.id = id;
        this.title = title;
        this.genre = genre;
        this.yearPublished = yearPublished;
        this.duration = duration;
        this.movieDescription = movieDescription;
        this.link = link;
        this.picturePath = picturePath;
    }

    public Movie(String title, String genre, int yearPublished, int duration, String movieDescription, String link, String picturePath) {
        this.title = title;
        this.genre = genre;
        this.yearPublished = yearPublished;
        this.duration = duration;
        this.movieDescription = movieDescription;
        this.link = link;
        this.picturePath = picturePath;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getYearPublished() {
        return yearPublished;
    }

    public void setYearPublished(int yearPublished) {
        this.yearPublished = yearPublished;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getMovieDescription() {
        return movieDescription;
    }

    public void setMovieDescription(String movieDescription) {
        this.movieDescription = movieDescription;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getPicturePath() {
        return picturePath;
    }

    public void setPicturePath(String picturePath) {
        this.picturePath = picturePath;
    }

    @Override
    public String toString() {
        return id + " - " + title + " {" + yearPublished + "}"; 
    }

    @Override
    public int compareTo(Movie o) {
        return title.compareTo(o.title);
    }
    
}
