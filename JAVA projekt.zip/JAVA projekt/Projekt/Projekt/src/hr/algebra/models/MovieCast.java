/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.models;

/**
 *
 * @author dbasi
 */
public class MovieCast {
    private int IDMovieCast;
    private int employeeID;
    private int movieID;

    public MovieCast() {
    }

    public MovieCast(int IDMovieCast, int employeeID, int movieID) {
        this.IDMovieCast = IDMovieCast;
        this.employeeID = employeeID;
        this.movieID = movieID;
    }

    public MovieCast(int employeeID, int movieID) {
        this.employeeID = employeeID;
        this.movieID = movieID;
    }

    public int getIDMovieCast() {
        return IDMovieCast;
    }

    public void setIDMovieCast(int IDMovieCast) {
        this.IDMovieCast = IDMovieCast;
    }

    public int getActorID() {
        return employeeID;
    }

    public void setActorID(int employeeID) {
        this.employeeID = employeeID;
    }

    public int getMovieID() {
        return movieID;
    }

    public void setMovieID(int movieID) {
        this.movieID = movieID;
    }
}
